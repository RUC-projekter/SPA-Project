﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.DTOs
{
    public class OftenWorkedWithDTO
    {
        public string? person_id { get; set; }

        public string? fullname { get; set;}

        public int? numberOfTitles { get; set; }
    }
}
