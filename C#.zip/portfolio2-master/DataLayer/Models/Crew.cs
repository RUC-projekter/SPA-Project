﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Models
{
    public class Crew
    {
        public string Id { get; set; }
        public string? Directors { get; set; }
        public string? Writers { get; set; }
    }
}
