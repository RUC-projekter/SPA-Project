﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Models
{
    public class PersonRatings
    {
        public string Id { get; set; }
        public decimal WeightedAverage { get; set; }
    }
}
