﻿namespace WebServer.Models
{
    public class OftenWorkedWithModel
    {
        public string Url { get; set; }
        public string? Name { get; set; }
    }
}
