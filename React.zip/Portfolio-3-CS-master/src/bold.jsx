

const Bold = ({greet, who}) => <b>{greet}{who} </b>;

export default Bold;